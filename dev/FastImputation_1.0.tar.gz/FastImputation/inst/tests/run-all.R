library(testthat)
library(FastImputation)

test_package("FastImputation")
