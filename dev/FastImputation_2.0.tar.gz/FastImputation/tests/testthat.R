library(testthat)
library(FastImputation)

test_check("FastImputation")
